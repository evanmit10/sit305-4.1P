package com.example.week4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TaskListActivity extends AppCompatActivity {

    RecyclerView recyclerViewMain;
    VerticalAdapter vAdapter;
    TaskManagerDB taskManagerDB;
    List<Task> taskList;
    Button backButton;
    Button clearTasks;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_list);

        backButton = findViewById(R.id.backButton);
        recyclerViewMain = findViewById(R.id.recyclerView);
        clearTasks = findViewById(R.id.clearAllTasks);
        taskManagerDB = new TaskManagerDB(this);
        createTaskList();

        //adds vertical dividers to the RecyclerView which is the list
        DividerItemDecoration divider = new DividerItemDecoration(recyclerViewMain.getContext(), DividerItemDecoration.VERTICAL);
        recyclerViewMain.addItemDecoration(divider);

        //enables or disables clearTasks if there are any tasks in the database or not
        clearTasks.setEnabled((!taskManagerDB.getAllTasks().isEmpty()));

        //set up the clear tasks button
        clearTasks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                taskManagerDB.deleteAllTasks();
                Toast.makeText(TaskListActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                onResume();
            }
        });

        //set up the back button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TaskListActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }


    //this snippet is to call the onResume method and then create the task list through the createTaskList method
    @Override
    protected void onResume() {
        super.onResume();
        createTaskList(); //display the task list
    }

    //this void is used to display the task list through RecyclerView and through Vertical Adapter
    private void createTaskList() {
        taskList = taskManagerDB.getAllTasks();
        vAdapter = new VerticalAdapter(taskList, new onItemClickListener() {
            @Override
            public void itemClick(Task task) {
                Intent intent = new Intent(TaskListActivity.this, TaskDetails.class);
                intent.putExtra("id", task.getId());
                startActivity(intent);
            }
        });
        recyclerViewMain.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewMain.setAdapter(vAdapter);
    }

    //This class makes VerticalAdapter work RecyclerView to show the tasks vertically
    public class VerticalAdapter extends RecyclerView.Adapter<VerticalAdapter.ViewHolder> {

        private List<Task> taskList;
        private final onItemClickListener listener;

        public VerticalAdapter(List<Task> taskList, onItemClickListener listener) {
            this.taskList = taskList;
            this.listener = listener;
        }

        //set up the recyclerview of submitted tasks that shows the title and date
        public class ViewHolder extends RecyclerView.ViewHolder {
            private TextView titleTextView;
            private TextView dueDateTextView;

            public ViewHolder(View itemView) {
                super(itemView);
                titleTextView = itemView.findViewById(R.id.titleDetailTextView);
                dueDateTextView = itemView.findViewById(R.id.dueDateDetailTextView);
            }

            public void bind(Task task, final onItemClickListener listener) {
                titleTextView.setText(task.getTitle()); //set the text of titleTextView to the title
                dueDateTextView.setText(task.getDueDate()); //set the text of dueDateTextView to the duedate
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.itemClick(task);
                    } //this calls itemClick on listener passing the clicked task as an argument which overall represents what will happen when a task is clicked from the RecyclerView
                });
            }
        }


        //This snippet makes the layout for the items in the RecyclerView by copying the layout from task_item.xml and putting it inside the ViewHolder
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.task_item, parent, false); //inflates task_item file to create new view object which would represent an item in the RecyclerView
            return new ViewHolder(view); //return the new viewholder
        }

        //this snippet would bind data to the ViewHolder objects which would result in updating the content of the tasks based on the item at a position of the RecyclerView
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            Task task = taskList.get(position); //gets the Task from taskList at a given position and assigns it to task
            holder.bind(task, listener); //binds the task to holder
        }

        //this snippet tells RecyclerView how many times it would display the tasks as well as the amount of the items it will show based on taskList

        @Override
        public int getItemCount() {
            if (this.taskList == null) { //if taskList is null
                return 0; //returns 0
            }
            return this.taskList.size(); //return the size of the taskList
        }
    }

    //this snippet shows that onItemClickListener is implemented to make the classes listen for click events on items in the RecyclerView with itemClick handling click events
    public interface onItemClickListener {
        void itemClick(Task task);
    }
}