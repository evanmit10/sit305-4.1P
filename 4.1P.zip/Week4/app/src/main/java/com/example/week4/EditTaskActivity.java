package com.example.week4;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;
import java.util.Locale;

public class EditTaskActivity extends AppCompatActivity {

    Task task;
    TaskManagerDB taskManagerDB;

    EditText textTitle;
    EditText textDescription;
    EditText textDueDate;

    Button saveChangesButton;
    Button backButton;

    Button datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);
        taskManagerDB = new  TaskManagerDB(this);

        textTitle = findViewById(R.id.editTitle);
        textDescription = findViewById(R.id.editDescription);
        textDueDate = findViewById(R.id.editDueDate);

        saveChangesButton = findViewById(R.id.SaveChangesBtn);
        backButton = findViewById(R.id.BackButton);
        datePicker = findViewById(R.id.pickDate);

        Intent intent = getIntent(); //This is used to get the Intent object that was used to start an activity or fragment.
        String id = intent.getStringExtra("id"); //This is used to extract a string passed with ID from the intent object
        task = taskManagerDB.getTask(id); //This is used to get a task from the SQLLiteDatabase based on the ID

        setUpTextView(); //This method is called to change the TextView content

        //this snippet sets up a OnClickListener method where clicking on the saveChangesButton would either update the task successfully or would tell you to fill out all sections through a Toast message.

        saveChangesButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String title = textTitle.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string
                String description = textDescription.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string
                String dueDate = textDueDate.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string

                if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty()) { //if any of the inputs is empty
                    Toast.makeText(EditTaskActivity.this, "Please enter all inputs", Toast.LENGTH_SHORT).show(); //it will show a Toast message to fill out the missing sections
                } else {
                    task = new Task(id, title, description, dueDate); //New object called Task with its attributes will be assigned to the variable called task
                    taskManagerDB.updateTask(task); //update the task
                    Toast.makeText(EditTaskActivity.this, "Task Updated Successfully", Toast.LENGTH_SHORT).show(); //show a Toast message saying the update was successful
                    setUpTextView(); //This method is called to change the TextView content
                }
            }
        });

        //this snippet sets up a OnClickListener method where clicking on the datePicker button would show the calendar to select a date

        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                DatePickerFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
            }
        });

        //this snippet sets up a OnClickListener method where clicking on the backButton button would take the user to the MainActivity class


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(EditTaskActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });



    }

    //this void takes the values of the year, month and day and formats them into a string and then sets the date string as a text called textDueDate
    public void setDueDate(int year, int month, int day) {
        String date = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, day);
        textDueDate.setText(date);
    }

    //this class displays the dialog of the date picker and then updates the duedate in the CreateTaskActivity class after selecting a date

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar cals = Calendar.getInstance(); //creates object called Calendar that is set to the current date and stores the final variable called cals
            int year = cals.get(Calendar.YEAR); //gets the current year from cals and sets it to the variable called year
            int month = cals.get(Calendar.MONTH); //gets the current month from cals and sets it to the variable called month
            int day = cals.get(Calendar.DAY_OF_MONTH); //gets the current day of month from cals and sets it to the variable called days
            return new DatePickerDialog(requireContext(), this, year, month, day); // The date picker dialog is initialised with the current date after creation. It also assigns a listener to handle events related to date selection and is associated with the current context.
        }

        //this method would trigger after the user picks the date and extracts the values of the year, month and day passes them to setDueDate to handle assigning the due date for the task being created.
        public void onDateSet(DatePicker view, int year, int month, int day) {
            ((EditTaskActivity) getActivity()).setDueDate(year, month, day);
        }
    }

    //this void updates the displayed texts in their TextViews to show the title, description and duedate of a task
    public void setUpTextView() {
        textTitle.setText(task.getTitle()); //set textTitle to the edited title of the task
        textDescription.setText(task.getDescription()); //set textDescription to the edited description of the task
        textDueDate.setText(task.getDueDate()); //set textDueDate to the edited dueDate of the task
    }

}
