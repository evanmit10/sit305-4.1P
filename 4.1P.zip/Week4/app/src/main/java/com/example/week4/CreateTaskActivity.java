package com.example.week4;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;
import java.util.Locale;

public class CreateTaskActivity extends AppCompatActivity {
    EditText textTitle;
    EditText textDescription;
    EditText textDueDate;
    Button createButton;
    Button backButton;

    Button datePicker;

    TaskManagerDB taskManagerDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);

        taskManagerDB = new TaskManagerDB(this);

        textTitle = findViewById(R.id.editTitle);
        textDescription = findViewById(R.id.editDescription);
        textDueDate = findViewById(R.id.editDueDate);

        createButton = findViewById(R.id.CreateButton);
        backButton = findViewById(R.id.BackButton);
        datePicker = findViewById(R.id.pickDate);

        //this snippet is a onClickListener method where clicking on the datePicker button will pop up a dialog that would allow the user to select the date
        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerFragment newFragment = new DatePickerFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");

            }
        });

        //this snippet is a onClickListener method where clicking on the createButton button would either create the task successfully or it would tell you to fill out the empty sections through a Toast message.

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = textTitle.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string
                String description = textDescription.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string
                String dueDate = textDueDate.getText().toString(); //fetches the text the user entered from the EditText field and stores it as a string

                if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty()) { //if any of the inputs is empty
                    Toast.makeText(CreateTaskActivity.this, "Please enter all inputs", Toast.LENGTH_SHORT).show(); //it will show a Toast message to fill out the missing sections
                } else {
                    String id = taskManagerDB.generateUniqueId(taskManagerDB);
                    Task task = new Task(id, title, description, dueDate); //New object called Task with its attributes will be assigned to the variable called Task
                    taskManagerDB.addTask(task); //this would create the task
                    Toast.makeText(CreateTaskActivity.this, "Task Created Successfully", Toast.LENGTH_SHORT).show(); //show a Toast message saying the task creation was successful
                    clearAllEditText(); //this would make every section that the has inputted erased once the task has been successfully submitted.
                }

            }
        });

        //this snippet sets up a onClickListener method where clicking on the backButton will go to the MainActivity class from CreateTaskActivity

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateTaskActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }

    //this void clears the text inputs after the task has been submitted successfully
    public void clearAllEditText() {
        textTitle.setText(""); //set text of textTitle to nothing
        textDescription.setText(""); //set text of textTitle to nothing
        textDueDate.setText(""); //set text of textTitle to nothing
    }

    //this void takes the values of the year, month and day and formats them into a string and then sets the date string as a text called textDueDate
    public void setDueDate(int year, int month, int day) {
        String date = String.format(Locale.getDefault(), "%04d-%02d-%02d", year, month + 1, day);
        textDueDate.setText(date);
    }

    //this class displays the dialog of the date picker and then updates the duedate in the CreateTaskActivity class after selecting a date

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar cals = Calendar.getInstance(); //creates object called Calendar that is set to the current date and stores the final variable called cals
            int year = cals.get(Calendar.YEAR); //gets the current year from cals and sets it to the variable called year
            int month = cals.get(Calendar.MONTH); //gets the current month from cals and sets it to the variable called month
            int day = cals.get(Calendar.DAY_OF_MONTH); //gets the current day of the month from cals and sets it to the variable called day
            return new DatePickerDialog(requireContext(), this, year, month, day); // The date picker dialog is initialised with the current date after creation. It also assigns a listener to handle events related to date selection and is associated with the current context.
        }

        //this method would trigger after the user picks the date and extracts the values of the year, month and day passes them to setDueDate to handle assigning the due date for the task being created.
        public void onDateSet(DatePicker view, int year, int month, int day) {
            ((CreateTaskActivity) getActivity()).setDueDate(year, month, day);
        }
    }
}
