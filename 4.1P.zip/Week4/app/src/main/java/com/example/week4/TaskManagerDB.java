package com.example.week4;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class TaskManagerDB extends SQLiteOpenHelper {
    private static final String TABLE_NAME = "tasks";

    private static final String DB_NAME = "taskManagerDatabase.db";


    //This constructor configures the TaskManagerDB object using the supplied context to manage a SQLitedatabase with a name and version.
    public TaskManagerDB(Context context) {
        super(context, DB_NAME, null, 1);
    }

    //this overridden method sets up a SQLlitedatabase by creating a table called tasks with columns when its created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlDB = "CREATE TABLE tasks (id TEXT PRIMARY KEY, title TEXT, description TEXT, dueDate TEXT)";
        db.execSQL(sqlDB);
    }

    //this overridden void upgrades the database from the old version to the new version
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    //this boolean method adds the new task to the SQLlitedatabase and returns true if adding it was successful, if not it will return false
    public Boolean addTask(Task task) {
        SQLiteDatabase sql_DB = getWritableDatabase(); //gets a writable SQLLiteDatabase
        ContentValues cal = new ContentValues(); //initialise object that is ContentValues called cal which is used to hold id, title, description and duedate values
        cal.put("id", task.getId()); //adds key value pair to cal where the value is obtained from getId which is a method.
        cal.put("title", task.getTitle()); //adds key value pair to cal where the value is obtained from getTitle which is a method.
        cal.put("description", task.getDescription()); //adds key value pair to cal where the value is obtained from getDescription which is a method.
        cal.put("dueDate", task.getDueDate()); //adds key value pair to cal where the value is obtained from getDuedate which is a method.

        long rowId = sql_DB.insert(TABLE_NAME, null, cal); //inserts key value pairs from cal into the database table and stores id of the new inserted row
        sql_DB.close(); //close the database
        if(rowId > -1) { //if rowid value is greater than -1
            System.out.println("Task added " + rowId); //print message task added to a specific rowid
            return true;
        } else {
            System.out.println("Insert failed | ERROR"); //print error message
            return false;
        }
    }

    //this method gets a task from the database based on the id and returns it as a object which is task
    public Task getTask(String id) {
        SQLiteDatabase sql_DB = this.getReadableDatabase(); //gets a readable SQLLiteDatabase
        Cursor query = sql_DB.query(TABLE_NAME, new String[] {"id", "title", "description", "dueDate"},
                "id=?", new String[] {id}, null, null, null, null); //executes a query on the database to get these columns from the specific table where the id would match the given id.
        if (query != null) { //if query is not null
            query.moveToFirst(); //move the cursor to the first row
        }
        Task task = new Task(query.getString(0), query.getString(1), query.getString(2), query.getString(3)); //creates a new task through extracting data from the current row of 'query'
        query.close(); //close the query
        sql_DB.close(); //close the database
        return task; //return the task
    }

    //this method gets every task from the database and returns them as a list of objects which is Task
    public List<Task> getAllTasks() {
        SQLiteDatabase sql_DB = getReadableDatabase(); //gets a readable SQLLiteDatabase
        Cursor query = sql_DB.query(TABLE_NAME, null, null, null, null, null, null); //executes a query on the database to get columns and rows from the specific table
        List<Task> result = new ArrayList<>(); //creates a new array list called result that will store objects from 'Task' that will be retrieved from the database

        while (query.moveToNext()) { //while moving the cursor to the next row in query in a loop
            result.add(new Task(query.getString(0), query.getString(1), query.getString(2), query.getString(3))); //add the task using the data from the current row from Cursor
        }
        query.close(); //close the query
        sql_DB.close(); //close the database
        return result; //return result
    }

    //this method updates a task from the database
    public Boolean updateTask(Task task) {
        SQLiteDatabase sql_DB = getWritableDatabase(); //gets a writable SQLLiteDatabase
        ContentValues cal = new ContentValues(); //initialise object that is ContentValues called cal which is used to hold id, title, description and duedate values
        cal.put("id", task.getId()); //adds key value pair to cal where the value is obtained from getId which is a method.
        cal.put("title", task.getTitle()); //adds key value pair to cal where the value is obtained from getTitle which is a method.
        cal.put("description", task.getDescription()); //adds key value pair to cal where the value is obtained from getDescription which is a method.
        cal.put("dueDate", task.getDueDate()); //adds key value pair to cal where the value is obtained from getDuedate which is a method.

        int numOfRowsAffected = sql_DB.update(TABLE_NAME, cal, "id = ?", new String[]{task.getId()}); //updates the row in the table based on the values from cal and the condition of the Id column matching the id of task
        sql_DB.close(); //close the database

        return numOfRowsAffected > 0; //return the number of rows that were affected being greater than 0
    }

    //this method deletes a task from the database and returns true if its deleted successfully, if not it would return false
    public Boolean deleteTask(String id) {
        SQLiteDatabase db = getWritableDatabase(); //gets a writable SQLLiteDatabase
        String[] whereArgs = {id}; //creates the string array and initialise it with the Id value
        int numRowsDeleted = db.delete(TABLE_NAME, "id" + "= ?", whereArgs); //deletes row from the table where the id column would match the value provided in whereArgs
        db.close(); //close the database
        if (numRowsDeleted > 0) //if number of rows deleted is greater than 0
        {
            return true;
        }
        else
        {
            return false;
        }

    }

    //this method deletes every task from the database of a specific table and will return true if successful and will return false if there's an error.
    public boolean deleteAllTasks()
    {
        SQLiteDatabase sql_DB = getReadableDatabase(); //gets a readable SQLLiteDatabase
        try {
            sql_DB.delete(TABLE_NAME, null, null);
            return true;
        } catch (Exception exception) {
            return false;
        }

    }


    //this method generates a 5 digit ID for a new task through checking existing IDs in the database and then return a new unique ID
    public String generateUniqueId(TaskManagerDB taskManagerDB)
    {
        List<Task> taskList = taskManagerDB.getAllTasks(); //gets all the tasks from the database using getAllTasks and assigns them to taskList
        int newId = 1; //set newId to 1
        //from this part up to the return part  is where it generates a unique id for the new task through checking every existing task's uniqueness in taskList. It wouuld continue to generate a new Id and check its uniqueness until a unique id is found which would return 5 digits as a string.
        boolean isUnique;
        do {
            isUnique = true;
            String newIdString = String.format("%05d", newId);
            for(Task task : taskList) {
                if (task.getId().equals(newIdString)) {
                    isUnique = false;
                    break;
                }
            }
            if (!isUnique) {
                newId++;
            }
        } while (!isUnique);
        return String.format("%05d", newId);
    }



}
