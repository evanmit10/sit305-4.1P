package com.example.week4;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TaskDetails extends AppCompatActivity {
    TaskManagerDB taskManagerDB;
    Task task;

    TextView idTextView;
    TextView titleTextView;
    TextView descriptionTextView;
    TextView dueDateTextView;

    Button deleteButton;

    Button backButton;

    Button editTaskButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.task_details_activity);

        idTextView = findViewById(R.id.idDetailTextView);
        titleTextView = findViewById(R.id.titleDetailTextView);
        descriptionTextView = findViewById(R.id.descriptionDetailTextView);
        dueDateTextView = findViewById(R.id.dueDateDetailTextView);
        deleteButton = findViewById(R.id.deleteButton);
        backButton = findViewById(R.id.backButton);
        editTaskButton = findViewById(R.id.editTaskButton);

        Intent intent = getIntent();

        String id = intent.getStringExtra("id"); //gets the value of the string that was passed using Intent with id as the key.


        //this snippet gets the details of a task from the database and display them in the UI of the activity and enables the delete and edit buttons
        taskManagerDB = new TaskManagerDB(this);
        String taskId = getIntent().getStringExtra("id"); //gets the extra string with id from Intent and stores taskId
        if (taskId != null) {
            task = taskManagerDB.getTask(taskId); //gets a specific task object from the database using taskId and assigns it to task.
            if(task != null) {
                idTextView.setText(task.getId()); //set text of idTextView to the given Id
                titleTextView.setText(task.getTitle()); //set text of titleTextView to the given title
                descriptionTextView.setText(task.getDescription()); //set text of descriptionTextView to the given description
                dueDateTextView.setText(task.getDueDate()); //set text of dueDateTextView to the given due date
                deleteButton.setEnabled(true); //set enabled of the delete button to be true (accessible)
                editTaskButton.setEnabled(true); //set enabled of the edit task button to be true (accessible)
            }
        }

        //this snippet is to make an onClickListener of the edit button to go to the EditTaskActivity class

        editTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(TaskDetails.this, EditTaskActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });

        //this snippet is to make an onClickListener of the delete button to delete a specific task if available

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(taskManagerDB.deleteTask(id)) //if task is going to be deleted
                {
                    Toast.makeText(TaskDetails.this, "Task is deleted", Toast.LENGTH_SHORT).show(); //if successful make a Toast message saying that the task is deleted
                    clearTaskTextView(); //after deletion, clear the user inputs in every section
                    deleteButton.setEnabled(false); //set enabled of delete button to false
                    editTaskButton.setEnabled(false); //set enabled of edit button to false
                }
                else
                {
                    Toast.makeText(TaskDetails.this, "Unable to delete Task", Toast.LENGTH_SHORT).show(); //if unsuccessful make a Toast message saying unable to delete task
                }
            }
        });

        //this snippet is to make an onClickListener of the back button to go back to a previous class which is TaskListActivity

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(TaskDetails.this, TaskListActivity.class);
                startActivity(intent);
            }
        });

    }

    //this method is used to clear a task and these placeholder values below will show once the task is cleared
    public void clearTaskTextView() {
        idTextView.setText("---------"); //set text of id to ---------
        titleTextView.setText("---------"); //set text of title to ---------
        descriptionTextView.setText("---------"); //set text of description to ---------
        dueDateTextView.setText("---------"); //set text of duedate to ---------
    }

}
